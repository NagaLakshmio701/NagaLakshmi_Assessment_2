﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASSESSMENT_2
{
    public class Book
    {
        public int BookId { get; set; }
        public string BookName { get; set; }
        public double Price { get; set; }
        public string Author { get; set; }
        public string Publisher { get; set; }

        public override string ToString()
        {
            return $"ID: {BookId}, Name: {BookName}, Price: {Price}, Author: {Author}, Publisher: {Publisher}";
        }

    }
}
